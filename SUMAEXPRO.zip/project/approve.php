<?php


require 'conn.php';

session_start();

$persal = $_GET['ans'];
$sql = "UPDATE subjects SET approved ='YES' WHERE persal= '$persal' " ;
$run = mysqli_query($conn, $sql);


    echo ' <script> alert("APPROVED") </script> ';
    Header("Location: admin.php");
    exit(0);
