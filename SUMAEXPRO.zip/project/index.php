<!DOCTYPE html>
<html>
<head>
    <title>Subjects Matter Expert Profile</title>
    
        <meta charset="UTF-8">
        
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
        <link rel="stylesheet" href="styles.css">
 
        
</head>



<?php
require 'conn.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $uploadDir = "uploads/"; // Create a directory called 'uploads' to store uploaded files
    $uploadFile = $uploadDir . basename($_FILES["file"]["name"]);

    // Check if the file is an image
    $imageFileType = strtolower(pathinfo($uploadFile, PATHINFO_EXTENSION));
    $allowedExtensions = array("jpg", "jpeg", "png", "gif");


    $names = filter_input(INPUT_POST, "names");
    $surname = filter_input(INPUT_POST, "surname");
    $persal = filter_input(INPUT_POST, "persal");
    $directory = filter_input(INPUT_POST, "directory");  
    $post = filter_input(INPUT_POST, "post");
    $service = filter_input(INPUT_POST, "service");
    $duration = filter_input(INPUT_POST, "duration");
    $interest = filter_input(INPUT_POST, "interest");
    $skill = filter_input(INPUT_POST, "skill");
    $qualities = filter_input(INPUT_POST, "qualities");
    $password = filter_input(INPUT_POST, "password");


    $position = filter_input(INPUT_POST, "position");
    $departmet = filter_input(INPUT_POST, "departmet");

    $answer = "NO";

    $sqlTest = "SELECT * from subjects WHERE persal='$persal' ";
    $runTest = mysqli_query($conn, $sqlTest);

    
    if(mysqli_num_rows($runTest)==0){
        
            $sql = "INSERT INTO subjects (persal, name, surname, directory, post, service, duration, interest, skill,qualities,password, profile,department, position ,approved) "
            . "VALUES ('$persal','$names','$surname','$directory','$post','$service','$duration','$interest','$skill','$qualities','$password','$uploadFile','$departmet','$position','$answer')";

        $result = mysqli_query($conn, $sql);
        ?>

            <div class="alert">
                <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
                <center> Persal Number already Registered.</center>
            </div>


        <?php
        Header("Location: login.php");
    


    }
    else
    {
        
        ?>

            <div class="alert">
                <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
                <center> Persal Number already Registered.</center>
            </div>


        <?php
    }


}


?>







<body>
    <div>
        <nav class="navbar navbar-light" style="background-color: yellow;">
            <label>   <img src="background.png" alt=""  style="width: 13rem;">  </label>
            <a href="login.php" class="btn btn-danger float-end">Back</a>
            
        </nav>

    </div>
    <br>
<div class="container">




<div class="">

</div>


    <div class="row">
        <div class="col-sm-12">
            
            <div class="card">
                <div class="card-header">
                    <div class="headers">Subjects Matter Expert Profile</div>
                </div>
                <div class="card-body">



                <div class="">
       
        
    
                <form action="index.php" method="POST" enctype="multipart/form-data">
                    
                    <table style="width: 100%;">
                        <tr>
                                <td>

                                    <div>
                                        <label for="">Full Names</label>
                                        <input type="text" name="names" class="form-control" placeholder="Full Names" required>
                                    </div> <br>
                                    <div>
                                        <label for="">Persal</label>
                                        <input type="number" name="persal" maxlength="10" class="form-control" placeholder="Persal Number" required>
                                    </div> 
                                    <div> <br>
                                        <label for="">Directorate</label>
                                        <input type="text" name="directory" class="form-control" placeholder="Directorate" required> 
                                    </div>
                                    <div> <br>
                                        <label for="">Department</label>
                                        <input type="text" name="departmet" class="form-control" placeholder="Department" required> 
                                    </div>

                                </td>
                                <td>
                                        <div>
                                            <label for="">Surname</label>
                                            <input type="text" name="surname" class="form-control" placeholder="surname" required> 
                                        </div> <br>

                                        <div>
                                            <label for="">Post Occupied</label>
                                            <input type="text" name="post" class="form-control" placeholder="Post Occupied" required> 
                                        </div> <br>
                                        <div>
                                            <label for="">Year Employed</label>
                                            <input type="month" name="service" class="form-control" placeholder="Years Employed" required>
                                        </div>
                                        <div> <br>
                                            <label for="">Years in Post Occupied</label>
                                            <input type="month" name="duration" class="form-control" placeholder="Years in Post Occupied" required>  
                                        </div>

                                </td>

                        </tr>
                    </table>
                    
                   <br>
                    
                    <label for="interest" >1. What do you like about the position/job?</label><br> 
                    <textarea name="interest" class="form-control" required> </textarea> <br> 
                    
                    <label for="skill">2. What skill set is needed/required in this position apart from what is in the job description?</label><br> 
                    <textarea name="skill" class="form-control" required> </textarea> <br> 
                    
                    <label for="qualities">3. What qualities are most valuable for a person to succeed in this position?</label><br> 
                    <textarea name="qualities" class="form-control" required> </textarea> <br> 
                    <div>
                        <label for="">Create Password</label>
                        <input type="password" name="password" class="form-control" required>
                    </div> <br>

                    

                    
                    <br>
                    <label for="file">Choose Profile Picture:</label>
                    <input type="file" name="file" id="file" class="form-control" required>
                    <br><br>
                            

                    <button type="submit" class="btn btn-success" name="submit">submit</button>
                    
                    <a class="btn btn-danger" href="login.php">back</a>
                    
                </form>
                </div>




                </div>
            </div>
        </div>
    </div>
</div>
<style>
     a{
            text-decoration: none;
            font-size: 1.2rem;
            
        }
        li{
          
            margin: 0rem 1rem;
            float: right;
        }
        ul{
            list-style: none;
            
        }
       

</style>
</body>
</html>



<style>
.alert {
  padding: 20px;
  background-color: #f44336;
  color: white;
}

.closebtn {
  margin-left: 15px;
  color: white;
  font-weight: bold;
  float: right;
  font-size: 22px;
  line-height: 20px;
  cursor: pointer;
  transition: 0.3s;
}

.closebtn:hover {
  color: black;
}
</style>