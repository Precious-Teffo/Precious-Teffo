<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <?php

    require('./fpdf185/fpdf.php');
    require 'conn.php';
    session_start();

        $temp = $_SESSION['temp'];
        echo'steyn'.$temp;

        $sql ="SELECT * FROM subjects WHERE persal='$temp' ";
        $run = mysqli_query($conn, $sql);
        $rows = mysqli_fetch_assoc($run);





 
    $pdf = new FPDF('p','mm','A4');
    $pdf->AddPage();



    $pdf->setFont('Arial','B',25);
    $pdf->cell(40, 10,'', 0, 0);
    $pdf->cell(59, 5, 'REPORT of Mr/Mrs '.$rows['surname'], 0, 1);


    $pdf->setFont('Arial','',15);


/*
Full texts
id	
persal	
name	
surname	
directory	
post	
service	
duration	
interest	
skill	
qualities	
password	
profile	
department	
position	
approved	*/


    $pdf->cell(10, 7,'', 0, 1);
    $pdf->cell(40, 7, 'Persal: ', 0, 0);
    $pdf->cell(20, 7, $rows['persal'] , 0, 1,'E');

    $pdf->cell(40, 7, 'NAME: ', 0, 0);
    $pdf->cell(20, 7, $rows['name'] , 0, 1,'E');


    
    $pdf->cell(40, 7, 'Surname: ', 0, 0);
    $pdf->cell(20, 7, $rows['surname'] , 0, 1,'E');

    $pdf->cell(40, 7, 'Directory: ', 0, 0);
    $pdf->cell(20, 7, $rows['directory'] , 0, 1,'E');



    $pdf->cell(40, 7, 'post: ', 0, 0);
    $pdf->cell(20, 7, $rows['post'] , 0, 1,'E');


    $pdf->cell(40, 7, 'Service: ', 0, 0);
    $pdf->cell(20, 7, $rows['service'] , 0, 1,'E');
    


    $pdf->cell(40, 7, 'Directory: ', 0, 0);
    $pdf->cell(20, 7, $rows['directory'] , 0, 1,'E');



    $pdf->cell(40, 7, 'duration: ', 0, 0);
    $pdf->cell(20, 7, $rows['duration'] , 0, 1,'E');


    $pdf->cell(40, 7, 'department: ', 0, 0);
    $pdf->cell(20, 7, $rows['department'] , 0, 1,'E');

    $pdf->cell(40, 7, '', 0, 0);
    $pdf->cell(20, 7,'' , 0, 1,'E');




    

    $pdf->setFont('Arial','B',15);
    $pdf->cell(40, 7, 'What do you like about the position/job? ', 0, 1);
    $pdf->setFont('Arial','',15);
    $pdf->cell(20, 7, $rows['interest'] , 0, 1,'E');
    $pdf->cell(20, 7,'' , 0, 1,'E');

    $pdf->setFont('Arial','B',15);
    $pdf->cell(40, 7, 'What skill set is required in this position? ', 0, 1);
    $pdf->setFont('Arial','',15);
    $pdf->cell(20, 7, $rows['skill'] , 0, 1,'E');
    $pdf->cell(20, 7,'' , 0, 1,'E');

    $pdf->setFont('Arial','B',15);
    $pdf->cell(40, 7, 'What qualities are most valuable for a person to succeed in this position? ', 0, 1);
    $pdf->setFont('Arial','',15);
    $pdf->cell(20, 7, $rows['qualities'] , 0, 1,'E');


    

    $pdf->Output();

?>
</body>
</html>