<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
 
</head>
<body>

    <?php
    require 'conn.php';
    session_start();
    
        $persal = $_SESSION['persal'];

        $sql="SELECT * FROM subjects WHERE persal='$persal' ";
        $run = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($run);

        $_SESSION['temp']= $persal;
    ?>
    

    <div>
        <nav class="navbar navbar-light" style="background-color: yellow;">
            <label>   <img src="background.png" alt=""  style="width: 13rem;">  </label>
            <a href="view_client.php" class="btn btn-danger float-end">Back</a>
            
        </nav>

    </div>


<br>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h4>UPDATE SKILLS</h4>
            </div>
            <div class="card-body">
                <form action="" type="submit" method="POST">
                    <textarea name="skill" class="form-control" style="height: 10rem" required> <?php echo''.$row['skill'] ?> </textarea>
                    <br>
                    
                    <button type="submit" name="btn_update" class="btn btn-info">update</button>
                    <a href="view_client.php" class="btn btn-danger">Back</a>
                </form>
            </div>
        </div>
    </div>
</body>
</html>

<?php

    if(isset($_POST['btn_update'])){

        $temp = $_POST['skill'];
        $sql_update="UPDATE subjects SET skill='$temp' WHERE persal='$persal' ";
        $execute = mysqli_query($conn, $sql_update);
        Header("Location: view_client.php");
        exit(0);
    }

?>

