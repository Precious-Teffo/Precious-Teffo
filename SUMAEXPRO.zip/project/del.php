<?php

require 'conn.php';
session_start();

$temp=$_GET['id'];

    $sqlDel = "DELETE FROM subjects WHERE persal = '$temp' ";
    $del = mysqli_query($conn, $sqlDel);
    



if($del){
    Header("Location: admin.php");
    exit(0);
}

?>


