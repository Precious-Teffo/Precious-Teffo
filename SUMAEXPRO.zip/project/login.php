<?php

require 'conn.php';
session_start();



if(isset($_POST['login_btn']))
{
    $persal = mysqli_real_escape_string($conn, $_POST['persal']);
    $pass = mysqli_real_escape_string($conn, $_POST['pass']);
    $check = mysqli_real_escape_string($conn, $_POST['check']);

  
    
    $_SESSION['persal'] = $persal;



    if($persal =="100" && $pass=="Admin" && $check=="admin"){
        header("Location: admin.php");
    }else{

        $st1 = "SELECT * FROM subjects WHERE persal = '$persal' ";
        $run = mysqli_query($conn, $st1);
        $rows = mysqli_fetch_assoc($run); 
    
        if(mysqli_num_rows($run) >0 && $check=="customer"){
           if($pass == $rows['password'])
           {
             header("Location: view_client.php"); 
           }else{
            
            ?>

                <div class="alert">
                    <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
                    <center> Wrong Password.</center>
                </div>


            <?php
           }
        }else{
           
            ?>

            <div class="alert">
                <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
                <center> Wrong Email/Persal.</center>
            </div>


        <?php
            
        }

    }
    

}
?>





<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
 
</head>

<body>
    
    
    
    <center>
        <div class="container">
            <h1 style="color: green;"><i>Welcome to Ledet</i></h1>
            
<br> 
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <label for="">LOGIN</label>
                        </div>
                        <form action="" method="POST">
                            <div class="card-body">
                                <div class="md">
                                    <label>Persal Number/Email</label>
                                    <input type="text" name="persal" class="form-control" placeholder="9876543" required>
                                   </div>
                                   <div class="md">
                                       <label>Password</label>
                                       <input type="password" name="pass" class="form-control" placeholder="**********" required>
                                      </div>
                                  </div>

                                  <div>
                                    <label for="">customer</label>
                                    <input type="radio" name="check" value="customer" required>
                                    <label for=""> Administrator</label>
                                    <input type="radio" name="check" value="admin" required>
                                  </div>

                                <div> <br>
                                    
                                    <button name="login_btn" type="submit" class="btn btn-info">Login</button> 
                                    <br>
                                    <a href="index.php"> <u>don't have account</u> </a>
                                    
                                </div> <br>
                             </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </center>
   
</body>



<style>
.card{
    width: 30rem;
}
.btn{
    width: 25rem;
    
}
label{
    font-size: 1.5rem;
}




body{
    background-image: url("");
    font-size: 20px;
    
}


        a{
            text-decoration: none;
            font-size: 1.2rem;
            
        }
       
       

</style>






<style>
.alert {
  padding: 20px;
  background-color: #f44336;
  color: white;
}

.closebtn {
  margin-left: 15px;
  color: white;
  font-weight: bold;
  float: right;
  font-size: 22px;
  line-height: 20px;
  cursor: pointer;
  transition: 0.3s;
}

.closebtn:hover {
  color: black;
}
</style>



</html>