<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
     
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
 
</head>


<?php

require 'conn.php';
session_start();

    $sql = "select * from subjects";
    $run = mysqli_query($conn, $sql);


?>


<body>
    <script>
        function preventBack(){
            window.history.forward();
        }

        setTimeout("preventBack()",0);
        window.onunload = function () { null };
    </script>


    <div>
        <nav class="navbar navbar-light" style="background-color: yellow;">
            <label>   <img src="background.png" alt=""  style="width: 13rem;">  </label>
            <a href="login.php" class="btn btn-danger float-end">LogOut</a>
            
        </nav>

    </div>

<br>

    <div class="container">
        <div class="card">
            <div>




                    <div class="card-header">
                        <label>     <h1> Administrator </h1>    </label>
                      
                    </div>
                    <div class="card-body">

                    <table class="table">

                        <thead>
                            <tr>
                                <td>PERSAL</td>
                                <td>SURNAME</td>
                                <td>NAME</td>
                                <td>APPROVED</td>
                                
                            </tr>
                        </thead>
                        <tbody>

                        
                            <?php

                            foreach($run as $row){ ?>
                                <tr> 
                                    <td>
                                        <?php echo ''.$row['persal'] ?>

                                    </td>
                                    <td>
                                        <?php echo ''.$row['surname'] ?>

                                    </td>
                                    <td>
                                        <?php echo ''.$row['name'] ?>

                                    </td>
                                    <td>
                                        <a href="approve.php?ans=<?php  echo ''.$row['persal'] ?>">  <?php echo ''.$row['approved'] ?>  </a>

                                    </td>

                                    <td>
                                        <td> <a href="client.php?id=<?php  echo ''.$row['persal'] ?>" class="btn btn-info" >view more</a> </td>
                                    </td>
                                </tr>
                                <?php
                             }
                            ?>

                        </tbody>
                    </table>
                        
                    </div>
                    
         




            </div>
        </div>
    </div>
</body>



</html>