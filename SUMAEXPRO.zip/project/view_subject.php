<!DOCTYPE html>
<html>
<head>
    <title>Subjects Matter Expert Profile</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
        <meta charset="UTF-8">
</head>
<body>
    <div class="outer">
        <div class="nav-bar">
            <ul><li><a href="index.php">Home</a></li></ul>
        </div>
        <form>
            <table>
    <?php
            require_once 'conn.php';

            $itemsPerPage = 10; // Number of items to display per page
            $currentpage = isset($_GET['page']) ? $_GET['page'] : 1; // Get the current page number from the URL or user input

            $offset = ($currentpage - 1) * $itemsPerPage;

            $query6 = "SELECT * FROM subjects LIMIT $offset, $itemsPerPage";
            $result6 = mysqli_query($conn, $query6);

            // Display the data
            
            echo "<form>";
            echo "<table>";
            echo "<tr><td>PERSAL</td><td>Full name</td><td>Position</td></tr>";

            while ($row = mysqli_fetch_row($result6)) {

            ?>
                
                <tr><td><?php echo $row['0']?></td><td><?php echo $row['1']?></td><td><?php echo $row['2']?>
                </td><td><button ><a href="subjects.php?viewid=<?php echo $view_id = $row['1']?>">Download Subjects</button></td></tr>

             <?php 

            }
            echo "</table>";
            echo "</form>";
            // Generate pagination links
            
            $query4 = "SELECT COUNT(*) as total FROM subjects";
            $result4 = mysqli_query($conn, $query4);
            $row = mysqli_fetch_assoc($result4);
            $totalPages = ceil($row['total'] / $itemsPerPage);
            
            for ($i = 1; $i <= $totalPages; $i++) {
                echo "<button><a href='view_subjects.php?page=$i'/>$i</button> ";
            }
            
            ?>
   
    </div>
</body>
</html>