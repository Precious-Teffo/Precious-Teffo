<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    


    <header>
        <ul>
            <li> <a href="contact.html">Contact us</a> </li>
            <li> <a href="registration.html">Registration</a> </li>
            <li> <a href="faculties.html">Faculties</a> </li>
            <li> <a href="campuses.html">Campuses</a> </li>
            <li> <a href="home.html">Home</a> </li>
        </ul>
        <div>
            <h1><i>TUT</i></h1> <br>
            <h2><i>people's university</i></h2>
        </div>
       

    </header>

<style>
    header{
            font-family: Arial;
            font-weight: bold;
            color: red;
            
        }

        a{
            text-decoration: none;
            font-size: 1.2rem;
            color: red;
        }
        li{
          
            margin: 0rem 1rem;
            float: right;
        }
        ul{
            list-style: none;
            
        }
</style>

</body>
</html>