<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
 

</head>
<body>

    <?php

    require 'conn.php';
    session_start();

    $persal = $_SESSION['persal'];

    $st1 = "SELECT * FROM subjects WHERE persal='$persal' ";
    $run = mysqli_query($conn, $st1);
    $rows = mysqli_fetch_assoc($run); 
    

     

?>
    
    <div>
        <nav class="navbar navbar-light" style="background-color: yellow;">
            <label>   <img src="background.png" alt=""  style="width: 13rem;">  </label>
            <a href="login.php" class="btn btn-danger float-end">Back</a>
            
        </nav>

    </div>


<div class="container">
   
<br>
<br>
                
   <h3 style="text-transform: uppercase;" class="float-end"> Mr/Mrs  <?php echo ''.$rows['surname'].' '.substr($rows['name'],0,1);   ?></h3>   
   
   
                     <h3 >   </h3>
                    


<br> <br>
<label style="width: 33%"> <h6>Directory</h6> </label>
<label style="width: 33%"> <h6>Department</h6> </label>
<label style="width: 33%"> <h6>Position</h6> </label>
    <div class="card">
        <table class="table">
            <tr>
                <td style="width: 33%"> <?php echo ''.$rows['directory']?> </td>
                <td style="width: 33%"> <?php echo ''.$rows['department']?> </td>
                <td style="width: 33%"> <?php echo ''.$rows['post']?> </td>
            </tr>
        </table>  
    </div>

    <table class="table">
        <tr>
            <td style="width: 30%;"><h2>Questions:</h2></td>
            <td style="width: 60%;"><h2>Answer:</h2></td>
        </tr>
        <tr>
            <td>
                <h5> What skill set is needed/required in this position apart from what is in the job description? </p>
            </td>
            <td >
                <?php echo ''.$rows['skill']?>     
            </td>
            <td>
                <a href="skill_update.php?id=<?php echo''.$persal ?>" class="btn btn-info">Update</a>
            </td>
        </tr>

        <tr>
            <td>
                <h5>  What do you like about the position/job?</h5>
            </td>
            <td>
                <?php echo ''.$rows['interest']?> 
            </td>
            <td>
                <a href="update_pos.php?id=<?php echo''.$persal ?>" class="btn btn-info">Update</a>
            </td>
        </tr>



        <tr>
            <td>
                <h5> What qualities are most valuable for a person to succeed in this position? </h5>
            </td>
            <td>
                <?php echo ''.$rows['qualities'] ?>    
            </td>
            <td>
                
                <a href="update_qualities.php?id=<?php echo''.$persal ?>" class="btn btn-info">Update</a>
            </td>
        </tr>
    </table>
</div>




</body>
</html>
