<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
 
</head>
<body>
    <br>
    <center>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <label for="">Registration</label>
                        </div>
                        <form action="" method="POST">
                            <div class="card-body">





                                <div>
                                    <input type="text" name="name" placeholder="Full Names" required>
                                </div> <hr>
                                <div>
                                    <input type="text" name="persal" placeholder="PERSAL Number" required>
                                </div> <br>
                                <input type="text" name="directory" placeholder="Directorate" required> <br>
                                <input type="text" name="post" placeholder="Post Occupied" required> <br>
                                <input type="text" name="service" placeholder="Years Employed" required> <br>
                                <input type="text" name="duration" placeholder="Years in Post Occupied" required> <br><br> 
                                
                                <label for="interest" >1. What do you like about the position/job?</label><br> 
                                <textarea name="interest" required> </textarea> <br> 
                                
                                <label for="skill">2. What skill set is needed/required in this position apart from what is in the job description?</label><br> 
                                <textarea name="skill" required> </textarea> <br> 
                                
                                <label for="qualities">3. What qualities are most valuable for a person to succeed in this position?</label><br> 
                                <textarea name="qualities" required> </textarea> <br> 
                                
                                <label for="file">Choose Profile Picture:</label>
                                <input type="file" name="file" id="file" required>
                                <br><br>
                                        
                                <input type="submit" value="Submit"><br>
                


                                    <br> 
                                    <button type="submit" name="btn_sub" class="btn btn-info">Register</button>
                                    <a href="index.php" class="btn btn-danger" name="btn_sub">Back</a>
                                </div> <br>
                             </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </center>
</body>

<style>
.card{
    width: 50rem;
}
.btn{
    width: 8rem;
}
</style>












<?php
require 'conn.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $uploadDir = "uploads/"; // Create a directory called 'uploads' to store uploaded files
    $uploadFile = $uploadDir . basename($_FILES["file"]["name"]);

    // Check if the file is an image
    $imageFileType = strtolower(pathinfo($uploadFile, PATHINFO_EXTENSION));
    $allowedExtensions = array("jpg", "jpeg", "png", "gif");
    
    if (!in_array($imageFileType, $allowedExtensions)) {
        echo "Only JPG, JPEG, PNG, and GIF files are allowed.";
    } else {
        // Check if the file already exists
        if (file_exists($uploadFile)) {
            echo "File already exists.";
        } else {
            // Upload the file
            if (move_uploaded_file($_FILES["file"]["tmp_name"], $uploadFile)) {
                echo "File is uploaded successfully.";
                // You can save the file path to a database here.
            } else {
                echo "File upload failed.";
            }
        }
    }
    
    

        $name = filter_input(INPUT_POST, "name");
        $persal = filter_input(INPUT_POST, "persal");
        $directory = filter_input(INPUT_POST, "directory");  
        $post = filter_input(INPUT_POST, "post");
        $service = filter_input(INPUT_POST, "service");
        $duration = filter_input(INPUT_POST, "duration");
        $interest = filter_input(INPUT_POST, "interest");
        $skill = filter_input(INPUT_POST, "skill");
        $qualities = filter_input(INPUT_POST, "qualities");
        
        $sql = "INSERT INTO subjects (persal, name, directory, post, service, duration, interest, skill,qualities,profile) "
                    . "VALUES ('$persal','$name','$directory','$post','$service','$duration','$interest','$skill','$qualities','$uploadFile')";

        $result = mysqli_query($conn, $sql);
    
        }

?>
</html>