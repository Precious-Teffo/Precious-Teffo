<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
       
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
 
</head>
<body>


<?php
    require 'conn.php';
    session_start();

        $temp = $_GET['id'];
        

        $sql ="SELECT * FROM subjects WHERE persal='$temp' ";
        $run = mysqli_query($conn, $sql);
        $rows = mysqli_fetch_assoc($run);


$_SESSION['temp'] = $temp;
    ?>


    <div>
        <nav class="navbar navbar-light" style="background-color: yellow;">
            <label>   <img src="background.png" alt=""  style="width: 13rem;">  </label>
            <a href="admin.php" class="btn btn-danger float-end">Back</a>
            
        </nav>

    </div>

<br>


    <div class="container">
        <div class="card">
            <div>

            </div>
                    <div class="card-header">
                        <label>     <h1> Administrator </h1>    </label>
                        
                    </div>

                    <div class="card-body">

                    <div  id="invoice">
                        
                    <table class="table">
                    <tr>
                        <th style="width: 20%;">    </th>
                        <td>    </td>
                    </tr>
                    <tr>
                        <td>   
                            <img src="<?php echo $rows['profile']?>" alt="my pic"style="width: 12rem; height: 12rem; border-radius: 100%;"> <br> <br>
                            <h4 style="text-transform: uppercase;">  <?php echo 'Mr/Mrs '. $rows['surname'] ?>  </h4>  <br>
                            
                        </td>
                        <td>    
                            <h5>  PERSAL NUMBER: </h5>
                            <h5>  SURNAME  </h5>
                            <h5>  DIRECTORY </h5>
                            <h5>  Post Occupied:  </h5>
                            <h5>  Year Of Employed:  </h5>
                            <h5>  Years in the Position: </h5>

                            <h5>  Department:  </h5>
                            <h5>  position:  </h5>
                        
                            
                    
                    
                        </td>

                        <td>    
                            <h5>  <?php echo ''. $rows['persal'] ?>  </h5>
                            <h5>  <?php echo ''. $rows['surname'] ?>  </h5>
                            <h5>  <?php echo ''. $rows['directory'] ?>  </h5>
                            <h5>  <?php echo ''. $rows['post'] ?>  </h5>
                            <h5>  <?php echo ''. $rows['service'] ?>  </h5>
                            <h5>  <?php echo ''. $rows['duration'] ?>  </h5>
                            <h5>  <?php echo ''. $rows['department'] ?>  </h5>
                            <h5>  <?php echo ''. $rows['position'] ?>  </h5>
                        
                    
                    
                        </td>
                        
                        
                    </tr>
            


            </div>




            
<br>

<table class="table">
   
    <tr>
        <td>
            <p> </p>
        </td>
        <td>
            <p><h5> What do you like about the position/job?  </h5></p>
        </td>
        <td>
            <p><?php echo ''. $rows['interest'] ?></p>
        </td>
        
    </tr>


    <tr>
        <td style="width: 20%;">
            <p> </p>
        </td>
        <td style="width: 40%;">
            <p><h5>  What skill set is needed/required in this position apart from what is in the job description?  </h5></p>
        </td>
        <td>
            <p><?php echo ''. $rows['skill'] ?></p>
        </td>
        
    </tr>



    <tr>
        <td>
            <p> </p>
        </td>
        <td>
            <p><h5>  What qualities are most valuable for a person to succeed in this position? </h5></p>
        </td>
        <td>
            <p><?php echo ''. $rows['qualities'] ?></p>
        </td>
        
    </tr>
</table>



<label>   <a href="genarete.php?id=<?php echo ''.$temp ?>" class="btn btn-primary" >download</a>  </label>


<a href="del.php?id=<?php echo ''.$temp ?>"class="btn btn-danger">DELETE Profile</a> 

        </div>
            
    </div>


</body>

</html>


