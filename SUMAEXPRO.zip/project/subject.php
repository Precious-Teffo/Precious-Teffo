<?php require 'dompdf/vendor/autoload.php';
 require_once 'conn.php';
//      require 'inv_script.php';
        if(isset($_GET['viewid'])){
            $id = $_GET['viewid'];
            $query7 = "SELECT * FROM subjects WHERE persal = '$id'";
            $result7 = mysqli_query($conn, $query7);
        
        
        } else {
            echo 'ID not found';
        }
        
        // Display the data

        while ($row = mysqli_fetch_row($result7)) {

       $persal = $row['1'];
       $name = $row['2'];
       $profile=$row['10'];

     
        }
    //calculates nights    
//    $date1=date_create($ARRIVAL_DATE);
//    $date2=date_create($DEPATURE_DATE);
//    $diff=date_diff($date1,$date2);
//    echo $diff->format("%R%a days");
    
//    //calculates amount
//    $adlt_amt = $ADULTS * 270;
//    $kid_amt = $KIDS * 180;
//    $pen_amt = $PENSIONERS * 200;
//    
//    $tot_amt = $adlt_amt + $kid_amt + $pen_amt;
        use Dompdf\Dompdf;
        
        $dompdf = new Dompdf();
        
        $dompdf ->loadHtml("Hello World <br><br>".
                "".$persal."<img src=\"".$profile."\"/>");
   
        
        $dompdf ->render();
        
        $dompdf ->stream("PlayofCode",array("Attachment" => 0));
                      
        // put your code here
        
       $conn->close();
        
        ?>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        Hello world 2
    </body>
</html>