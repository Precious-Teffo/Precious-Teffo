<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "survey";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to count participants
$sql = "SELECT COUNT(*) AS Full_name_count FROM respond";

// Execute SQL query
$result = $conn->query($sql);

// Check if there are any rows returned
if ($result->num_rows > 0) {
    // Fetch the result
    $row = $result->fetch_assoc();
    
    // Output the count of participants
    echo "Number of participants: " . $row["Full_name_count"]."<br>";
} else {
    echo "No participants found";
}



// SQL query to retrieve gender data
$sql = "SELECT gender, COUNT(*) AS gender_count FROM respond GROUP BY gender";

// Execute SQL query
$result = $conn->query($sql);

// Check if there are any rows returned
if ($result->num_rows > 0) {
    // Loop through each row
    while ($row = $result->fetch_assoc()) {
        // Output gender and count
        echo "Gender: " . $row["gender"] . " - Count: " . $row["gender_count"] . "<br>";
    }
} else {
    echo "No gender data found";
}


// SQL query to retrieve age data
$sql = "SELECT age, COUNT(*) AS age_count FROM respond GROUP BY age";

// Execute SQL query
$result = $conn->query($sql);

// Check if there are any rows returned
if ($result->num_rows > 0) {
    // Loop through each row
    while ($row = $result->fetch_assoc()) {
        // Output age and count
        echo "Age: " . $row["age"] . " - Count: " . $row["age_count"] . "<br>";
    }
} else {
    echo "No age data found";
}

// SQL query to find the minimum age
$sql = "SELECT MIN(age) AS min_age FROM respond";

// Execute SQL query
$result = $conn->query($sql);

// Check if there are any rows returned
if ($result->num_rows > 0) {
    // Fetch the result
    $row = $result->fetch_assoc();
    
    // Output the minimum age
    echo "Minimum Age: " . $row["min_age"];
} else {
    echo "No data found";
    
}

// Close database connection

$conn->close();
?>
