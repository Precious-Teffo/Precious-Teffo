<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "survey"; //DATABSE NAME
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$Fullname = filter_input(INPUT_POST, "Fullname");
$Gender = filter_input(INPUT_POST, "Gender");
$Age = filter_input(INPUT_POST, "Age");
$Commit = filter_input(INPUT_POST, "Commit");
$Reasons = filter_input(INPUT_POST, "Reasons");

//respond is database table
$sql = "INSERT INTO respond (full_name, Gender, age, salary_commit,reason_commit) VALUES ('$Fullname', '$Gender', '$Age', '$Commit', '$Reasons')";
if ($conn->query($sql) === TRUE) {
    echo "Data saved successfully";
    
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
    
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Survey</title>
    <link rel="stylesheet" href="styles.php">
</head>
<style>
    body {
    font-family: Arial, sans-serif; 
	margin: 0; 
	padding: 20px; 
	background-color: #FF1493; 
} 

form { 
	max-width: 600px; 
	margin: 0 auto; 
	padding: 20px; 
	background-color: #fff; 
	border-radius: 10px; 
	box-shadow: 0 0 10px
		rgba(0, 0, 0, 0.1); 
} 


h1 {
    text-align: center;
    font: bold;
    
}

form {
    max-width: 400px;
    margin: 0 auto;
}

.input-group {
    padding: 10px; 
	box-sizing: border-box; 
	margin: 1.2rem 0; 
}

label {
    display: block;
    margin-bottom: 5px;
}

input[type="text"],
input[type="number"],
input[type="email"] {
    width: 100%;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

button { 
	width: 100%; 
	padding: 10px; 
	background-color: blue; 
	color: white; 
	border: none; 
	border-radius: 5px; 
	cursor: pointer; 
} 

button:hover { 
	background-color:#FF1493 ; ; 
} 

</style>
<body>
    <h1>Welcome alcohol committing survey</h1>
    <form action="index.php" method="post">
        <div class="input-group">
            <input  Placeholder = "Full Names" type="text" name="Fullname" required>
        </div>
        <div class="input-group">
            <label>Gender</label>
             <select name="Gender">
                 <option value="Male"> Male </option>
                 <option value="Female"> Female </option>
             </select>
        </div>
        <div class="input-group">
            <input  Placeholder = "Age" type="text" name="Age" required>
        </div>
         <div class="input-group">
             <label>Salary committed to alcohol every month</label>
             <select name="Commit">
                 <option value="10"> 0% </option>
                 <option value="20"> 10 - 20% </option>
                 <option value="30"> 20 - 30% </option>
                 <option value="40"> 30 - 50% </option>
                 <option value="50"> 50%+ </option>
             </select>
        </div>
        
        <div class="input-group">
             <label>Reason why you commit the percentage mentioned above </label>
             <select name="Reasons">
                 <option value="I drink alcohol for fun/occasional"> I drink alcohol for fun/occasional  </option>
                 <option value="They will buy for me out there"> They will buy for me out there </option>
                 <option value="I am pushing lifestyle and they should know ke le para"> I am pushing lifestyle and they should know ke le para </option>
                 <option value="I relive stress when I am drunk"> I relive stress when I am drunk </option>
             </select>
        </div>
       
        <button type="submit">Submit</button>
        <a href="compute_values.php">Click Here</a> 
        
    </form>
</body>
</html>
