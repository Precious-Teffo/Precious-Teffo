<?php 
session_start(); 

// Start the session 
// Check if the add to cart button is clicked 
if (isset($_POST["add_to_cart"])) { 
	
	// Get the product ID from the form 
	$product_id = $_POST["product_id"]; 
	
	// Get the product quantity from the form 
	$product_quantity = $_POST["product_quantity"]; 

	// Initialize the cart session variable 
	// if it does not exist 
	if (!isset($_SESSION["cart"])) { 
		$_SESSION["cart"] = []; 
		header("location:cart.php"); 
	} 

	// Add the product and quantity to the cart 
	$_SESSION["cart"][$product_id] = $product_quantity; 
	header("location:cart.php"); 
} 
?> 
<!DOCTYPE html> 
<style>
    body { 
	margin: 0; 
	padding: 0; 
	background-color: #FFE4C4; 
	color: blue; 
	font-family: Arial, sans-serif; 
} 

header { 
	background-color: #FFE4C4; 
	color: blue; 
	padding: 20px; 
} 

nav { 
	background-color: blue; 
	padding: 10px; 
} 

nav ul { 
	list-style: none; 
	margin: 2px; 
	padding: 0; 
} 
nav a { 
	color: white; 
	text-decoration: none; 
	padding: 2px; 
	display: flex; 
	cursor: pointer; 
} 

nav a:hover { 
	background-color: #FF1493; 
	color: red; 
} 

main { 
	max-width: 1200px; 
	margin: 0 auto; 
	padding: 20px; 
} 

section { 
	margin-bottom: 20px; 
} 

h2 { 
	font-size: 32px; 
	margin-top: 0; 
} 

ul { 
	list-style: none; 
	margin: 0; 
	padding: 0; 
	display: flex; 
	flex-wrap: wrap; 
} 

li { 
	margin-right: 20px; 
	margin-bottom: 20px; 
	flex-basis: calc(33.33% - 20px); 
} 

h3 { 
	font-size: 24px; 
	margin-top: 0; 
} 

img { 
	max-width: 200px; 
	height: 200px; 
	margin-bottom: 10px; 
} 

button { 
	background-color: #333; 
	color: #fff; 
	border: none; 
	padding: 10px; 
	cursor: pointer; 
}

</style>
<html> 
	<head> 
		<title>clothes shop web application</title> 
	</head> 
	<body> 
		<header> 
			<h1>Welcome to clothes shop web application</h1> <?php  
                        
			?>  
		</header> 
		<nav> 
			<ul> 
				<li><a href="shop.php">Home</a></li> 
				<li><a href="shop.php">Shop</a></li> 
				<li><a href="cart.php">Cart</a></li> 
				<li><a href="logout.php">Logout</a></li> 

			</ul> 
		</nav> 
		<main> 
			<section> 
				<h2>Clothes</h2> 
				<ul> 
					<li> 
						<h3>T-shirts</h3> 
						<img src= 
"https://bonblom.co.za/wp-content/uploads/2022/04/mens-tshirt-1.jpg"
							alt="Product 1"> 
						<p>Available with white,black or blue</p>
                                                <p>From size xss to XXXL</p>
						<p><span>R60</span></p> 

						<form method="post" action="shop.php"> 
							<input type="hidden"
								name="product_id"
								value="1"> 
							<label for="product1_quantity"> 
								Quantity: 
							</label> 
							<input type="number"
								id="product1_quantity"
								name="product_quantity"
								value=""
								min="0"
								max="10"> 
							<button type="submit"
									name="add_to_cart"> 
								Add to Cart</button> 
						</form> 
					</li> 
					<li> 
						<h3>Puffer Jackets</h3> 
						<img src= 
"https://www.outdoorlife.com/wp-content/uploads/2023/02/01/Big-Agnes-Womens-Luna-Jacket.jpg?w=645"
							alt="Product 2"> 
						<p>With different colors</p> 
                                                <p>From size s to XXXL</p>
						<p> 
							<span>R300</span> 
						</p> 

						<form method="post" action="shop.php"> 
							<input type="hidden"
								name="product_id"
								value="2"> 
							<label for="product2_quantity"> 
								Quantity: 
							</label> 
							<input type="number"
								id="product2_quantity"
								name="product_quantity"
								value=""
								min="0"
								max="10"> 
							<button type="submit"
									name="add_to_cart"> 
								Add to Cart 
						</button> 
						</form> 
					</li> 
					<li> 
						<h3>Pants</h3> 
						<img src= 
"https://www.capetownclothing.com/wp-content/uploads/2019/10/0002060_berlei-pants.jpeg"
							alt="Product 3"> 
						<p>Ladies pants</p> 
                                                <p>From size s to XXXL</p>
						<p> 
							<span>R150</span> 
						</p> 

						<form method="post" action="shop.php"> 
							<input type="hidden"
								name="product_id"
								value="3"> 
							<label for="product3_quantity"> 
								Quantity
							</label> 
							<input type="number"
								id="product3_quantity"
								name="product_quantity"
								value=""
								min="0"
								max="10"> 
							<button type="submit"
									name="add_to_cart"> 
								Add to Cart 
							</button> 
						</form> 
					</li> 
								
					<!-- Add forms for the other products here --> 
				</ul> 
			</section> 
		</main> 
		<footer> 
			<p>&copy; 2024 clothes shop web application</p> 
		</footer> 
		<script src="shop.php"></script> 
	</body> 
</html>
