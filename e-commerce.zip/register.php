<?php 
if ($_SERVER["REQUEST_METHOD"] == "POST") { 
	$name = $_POST["name"]; 
	$username = $_POST["username"]; 
	$email = $_POST["email"]; 
	$password = $_POST["password"]; 
	
	// Hash the password 
	$hashed_password = password_hash($password, PASSWORD_BCRYPT); 
	$host = "localhost"; 
	$dbname = "e-commerce"; 
	$username_db = "root"; 
	$password_db = ""; 
	try { 
		$db = new PDO( 
		"mysql:host=$host;dbname=$dbname", 
	        $username_db, $password_db); 
		$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
		
		// Insert the user into the database 
		$stmt = $db->prepare( 
		"INSERT INTO user (name,username,email, password) 
			VALUES (:name, :username, :email,:password)"); 
		$stmt->bindParam(":name",$name); 
		$stmt->bindParam(":username",$username); 
		$stmt->bindParam(":email",$email); 
		$stmt->bindParam(":password",$hashed_password); 
		$stmt->execute(); 
		echo "<h2>Registration Successful</h2>"; 
		echo "Thank you for registering, " . $name . "!<br>"; 
		echo "You'll be redirected to login page in 5 seconds"; 
		header("refresh:3;url=Login.php"); 
	} 
	catch(PDOException $e) { 
		echo "Connection failed: " . $e->getMessage(); 
	} 
} 
?>

<!DOCTYPE html> 
<html> 
<head> 
	<title>Registration Page</title> 	
</head> 
<style>
    body { 
background-color: #FFE4C4; 
} 
.container { 
display: flex; 
flex-direction: column; 
justify-content: center; 
align-items: center; 
height: 100vh; 
} 
form { 
display: flex;
flex-direction: column; 
align-items: center; 
} 
label { 
display: block; 
margin-bottom: 5px; 
} 
input[type="text"], 
input[type="email"], 
input[type="password"] { 
width: 100%; 
padding: 10px; 
margin-bottom: 20px; 
border: 1px solid #ccc; 
border-radius: 5px; 
} 
input[type="submit"] { 
background-color: blue; 
color: white; 
padding: 10px 20px; 
border: none; 
border-radius: 5px; 
cursor: pointer; 
} 

input[type="submit"]:hover { 
background-color:#FF1493 ; 
}

</style>

<body> 
	<div class="container"> 
		<h1>Registration Page</h1> 
		<form method="post" action="register.php"> 
			<label for="name">Name </label> 
			<input type="text"
				id="name"
				name="name" required> 
			<label for="username">Username</label> 
			<input type="text"
			        id="username"
				name="username" required> 
                        <label for="email">Email</label> 
			<input type="email"
				id="email"
				name="email" required> 
                        <label for="password">Password</label> 
			<input type="password"
				id="password"
				name="password" required> 

			<input type="submit"
				value="Register"> 
		</form> 
		<p> Already have an account?</p> 
		<a href="Login.php">Click Here</a> 
	</div> 
	<br> 
</body> 

</html>
