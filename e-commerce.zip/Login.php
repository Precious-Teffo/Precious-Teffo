<?php 

if ($_SERVER["REQUEST_METHOD"] == "POST") { 
	$username = $_POST["username"]; 
	$password = $_POST["password"]; 

	// Connect to the database 
	$host = "localhost"; 
	$dbname = "e-commerce"; 
	$username_db = "root"; 
	$password_db = ""; 

	try { 
		$db = new PDO( 
			"mysql:host=$host;dbname=$dbname", 
			$username_db, 
			$password_db
		); 
		$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 

		// Check if the user exists in the database 
		$stmt = $db->prepare("SELECT * FROM user WHERE username = :username"); 
		$stmt->bindParam(":username", $username); 
		$stmt->execute(); 
		$user = $stmt->fetch(PDO::FETCH_ASSOC); 

		if ($user) { 
			// Verify the password 
			if (password_verify($password, $user["password"])) { 
				session_start(); 
				$_SESSION["user"] = $user; 

				echo '<script type="text/javascript"> 
	window.onload = function () { 
		alert("Welcome to GFG shopping website"); 
		window.location.href = "shop.php"; 
	}; 
</script> 
'; 
			} else { 
				echo "<h2>Login Failed</h2>"; 
				echo "Invalid email or password."; 
			} 
		} else { 
			echo "<h2>Login Failed</h2>"; 
			echo "User doesn't exist"; 
		} 
	} catch (PDOException $e) { 
		echo "Connection failed: " . $e->getMessage(); 
	} 
} 
?>

<!DOCTYPE html> 
<html> 
<head> 
	<title>Login Page</title> 
</head>
<style>
    body { 
background-color: #FFE4C4; 
} 
.container { 
display: flex; 
flex-direction: column; 
justify-content: center; 
align-items: center; 
height: 100vh; 
} 
form { 
display: flex;
flex-direction: column; 
align-items: center; 
} 
label { 
display: block; 
margin-bottom: 5px; 
} 
input[type="text"], 
input[type="email"], 
input[type="password"] { 
width: 100%; 
padding: 10px; 
margin-bottom: 20px; 
border: 1px solid #ccc; 
border-radius: 5px; 
} 
input[type="submit"] { 
background-color: blue; 
color: white; 
padding: 10px 20px; 
border: none; 
border-radius: 5px; 
cursor: pointer; 
} 

input[type="submit"]:hover { 
background-color:#FF1493 ; 
}
</style>

<body> 
	<div class="container"> 
		<h1>Login Page</h1> 
		<form method="post"
			action="login.php"> 
			<label for="username">Username</label> 
			<input type="text"
				id="username"
				name="username" required> 
                        <label for="password">Password</label> 
			<input type="password"
				id="password"
				name="password" required> 

			<input type="submit"
				value="Login"> 
		</form> 
		<br><br> 
		<p> Don't have an account? 
			<a href="register.php">Click Here</a> 
		</p> 
	</div> 
</body> 

</html>
