
package game;


public class Game {

    
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
