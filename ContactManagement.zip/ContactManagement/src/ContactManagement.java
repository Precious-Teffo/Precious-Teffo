import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ContactManagement {
    private List<Contact> contacts;
    private Scanner scanner;

    public ContactManagement() {
        contacts = new ArrayList<>();
        scanner = new Scanner(System.in);
    }

    public void run() {
        while (true) {
            System.out.println("Contact Manager");
            System.out.println("1. Add new contact");
            System.out.println("2. View contact list");
            System.out.println("3. Edit existing contact");
            System.out.println("4. Delete contact");
            System.out.println("5. Save and exit");

            System.out.print("Choose an option: ");
            int option = scanner.nextInt();
            scanner.nextLine(); // Consume newline left-over

            switch (option) {
                case 1:
                    addNewContact();
                    break;
                case 2:
                    viewContactList();
                    break;
                case 3:
                    editExistingContact();
                    break;
                case 4:
                    deleteContact();
                    break;
                case 5:
                    saveAndExit();
                    return;
                default:
                    System.out.println("Invalid option. Please choose a valid option.");
            }
        }
    }

    private void addNewContact() {
        System.out.print("Enter name: ");
        String name = scanner.nextLine();

        System.out.print("Enter phone number: ");
        String phoneNumber = scanner.nextLine();

        System.out.print("Enter email address: ");
        String emailAddress = scanner.nextLine();

        Contact contact = new Contact(name, phoneNumber, emailAddress);
        contacts.add(contact);

        System.out.println("Contact added successfully!");
    }

    private void viewContactList() {
        if (contacts.isEmpty()) {
            System.out.println("No contacts available.");
        } else {
            for (int i = 0; i < contacts.size(); i++) {
                Contact contact = contacts.get(i);
                System.out.println("Contact " + (i + 1));
                System.out.println("Name: " + contact.getName());
                System.out.println("Phone Number: " + contact.getPhoneNumber());
                System.out.println("Email Address: " + contact.getEmailAddress());
                System.out.println();
            }
        }
    }

    private void editExistingContact() {
        if (contacts.isEmpty()) {
            System.out.println("No contacts available.");
        } else {
            System.out.print("Enter the contact number you want to edit: ");
            int contactNumber = scanner.nextInt();
            scanner.nextLine(); // Consume newline left-over

            if (contactNumber > 0 && contactNumber <= contacts.size()) {
                Contact contact = contacts.get(contactNumber - 1);

                System.out.print("Enter new name (press enter to skip): ");
                String name = scanner.nextLine();
                if (!name.isEmpty()) {
                    contact.setName(name);
                }

                System.out.print("Enter new phone number (press enter to skip): ");
                String phoneNumber = scanner.nextLine();
                if (!phoneNumber.isEmpty()) {
                    contact.setPhoneNumber(phoneNumber);
                }

                System.out.print("Enter new email address (press enter to skip): ");
                String emailAddress = scanner.nextLine();
                if (!emailAddress.isEmpty()) {
                    contact.setEmailAddress(emailAddress);
                }

                System.out.println("Contact updated successfully!");
            } else{
                System.out.println("Invalid contact number.");
            }
        }
    }

    private void deleteContact() {
        if (contacts.isEmpty()) {
            System.out.println("No contacts available.");
        } else {
            System.out.print("Enter the contact number you want to delete: ");
            int contactNumber = scanner.nextInt();
            scanner.nextLine(); // Consume newline left-over

            if (contactNumber > 0 && contactNumber <= contacts.size()) {
                contacts.remove(contactNumber - 1);
                System.out.println("Contact deleted successfully!");
            } else {
                System.out.println("Invalid contact number.");
            }
        }
    }

    private void saveAndExit() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("contacts.dat"))) {
            oos.writeObject(contacts);
            System.out.println("Contacts saved successfully!");
        } catch (IOException e) {
            System.out.println("Error saving contacts: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        ContactManagement contactManager = new ContactManagement();
        contactManager.run();
    }
}