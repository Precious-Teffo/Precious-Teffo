

/**
 *
 * @author PK Teffo
 */
public class contactsManager
{
   private String name;
   private String phoneNumber;
   private String emailAddress;
   
   public contactsManager(String name, String phoneNumber, String emailAddress){
       
   }
    public String getName() {
        return name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmailAddress() {
        return emailAddress;
    }
    public void setName(String name) {
        this.name = name;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    

 
}
